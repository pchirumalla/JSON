import org.apache.commons.lang3.StringUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SwingGUI extends JPanel {
    public SwingGUI() {
        initializeUI();
    }
    private void initializeUI() {
        this.setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(1000, 500));

        final JTextArea textArea = new JTextArea();

        // Set the contents of the JTextArea.
        String text = "Paste the text containing the JSON.";
        textArea.setText(text);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        JScrollPane panel = new JScrollPane(textArea);
        panel.setPreferredSize(new Dimension(500, panel.getComponents().length * 1000));
        panel.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        JButton button = new JButton("Convert");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the contents of the JTextArea component.
                String contents = textArea.getText();
                textArea.setText("");
                System.out.println("json contents = " + contents);
                StringBuilder sb= new StringBuilder();
                String[] lines = contents.split("profile=claim_submittedclaimapi_parallel");
                for(String line: lines){
                    if(!line.contains("jsonLine")) continue;
                    line = StringUtils.substringBetween(line, "BaseClaimProcessorBean.process()  -", "[user=tomcat]").trim();
                    sb.append(line);
                 }
                textArea.append(sb.toString());
                System.out.println("json contents = " + sb);
            }
        });
        this.add(panel, BorderLayout.CENTER);
        this.add(button, BorderLayout.SOUTH);
    }

    public static void showFrame() {
        JPanel panel = new SwingGUI();
        panel.setOpaque(true);

        JFrame frame = new JFrame("Read Json");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                SwingGUI.showFrame();
            }
        });
    }
}