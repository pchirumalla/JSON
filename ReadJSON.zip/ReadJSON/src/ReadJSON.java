import org.apache.commons.lang3.StringUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class ReadJSON extends JPanel {
    public ReadJSON() {
        initializeUI();
    }
    private void initializeUI() {
        this.setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(1000, 500));

        final JTextArea textArea = new JTextArea();

        // Set the contents of the JTextArea.
        String text = "Paste the text containing the JSON.";
        textArea.setText(text);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        JScrollPane panel = new JScrollPane(textArea);
        panel.setPreferredSize(new Dimension(500, panel.getComponents().length * 1000));
        panel.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        JButton button = new JButton("Convert");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the contents of the JTextArea component.
                String contents = textArea.getText();
                textArea.setText("");
                StringBuilder sb= new StringBuilder();
                String[] lines =contents.split("env="); //contents.split("profile=claim_submittedclaimapi_parallel");
                List<String> jsonLines = new ArrayList<>();
                for(String line: lines){
                    jsonLines.add(line);
                }
                StringBuilder json = readJSON(jsonLines);
                textArea.append(json.toString());
                System.out.println("json contents = " + sb);
            }
        });
        this.add(panel, BorderLayout.CENTER);
        this.add(button, BorderLayout.SOUTH);
    }

    public static void showFrame() {
        JPanel panel = new ReadJSON();
        panel.setOpaque(true);

        JFrame frame = new JFrame("Read Json");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ReadJSON.showFrame();
            }
        });
    }

    private StringBuilder readJSON(java.util.List<String> lines){
        ListIterator linesList = lines.listIterator();
        //
        Map<String, java.util.List<String>> map = new HashMap<>();
        java.util.List<String> keyLines  = new ArrayList<>();
        boolean fisrtJSONLineFound = false;
        boolean JSNOLineNotFoundAfterThefisrtJSONLineFound = false;
        String key = StringUtils.EMPTY;
        int noOfLines = 0;
        while(linesList.hasNext()){
            noOfLines++;
            String line = linesList.next().toString();
            if(!line.contains("jsonLine") || line.equals("")) {
                linesList.remove();
                noOfLines--;
                if(fisrtJSONLineFound && !line.equals("")){
                    JSNOLineNotFoundAfterThefisrtJSONLineFound = true;
                }else {
                   continue;
                }
            }
            if(JSNOLineNotFoundAfterThefisrtJSONLineFound || noOfLines==lines.size()){
                if(!JSNOLineNotFoundAfterThefisrtJSONLineFound && noOfLines == lines.size()){
                    keyLines.add(line);
                }
                map.put(key, keyLines);
                fisrtJSONLineFound = true;
                JSNOLineNotFoundAfterThefisrtJSONLineFound= false;
                key= StringUtils.EMPTY;
                keyLines = new ArrayList<>();
                continue;
            }

            if(!fisrtJSONLineFound) fisrtJSONLineFound = true;
            keyLines.add(line);
            if(StringUtils.isBlank(key)){
                int beginIndex = line.indexOf("jsonLine") + "jsonLine".length() + 3;
                int endIndex =line.indexOf("-") + 1;
                key = StringUtils.substring(line, beginIndex, endIndex);
            }

        }
        StringBuilder jsonString= new StringBuilder();
        Iterator iterator =  map.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry<String, java.util.List<String>> entry = (Map.Entry<String, java.util.List<String>>) iterator.next();
            String lineKey = entry.getKey();
            if(StringUtils.isBlank(lineKey)){
                continue;
            }
            List<String> jsonLines = entry.getValue();
            StringBuilder sb = new StringBuilder();
            for(String line: jsonLines){
                line = StringUtils.substringBetween(line, lineKey, "[user=tomcat]").trim();
                sb.append(line);
            }
            jsonString.append(lineKey);
            jsonString.append("\r\n*******************************************************************************************************");
            jsonString.append("\r\n"+sb.toString()+"\r\n");
            jsonString.append("\r\n*******************************************************************************************************");
       }
        return jsonString;
    }
}